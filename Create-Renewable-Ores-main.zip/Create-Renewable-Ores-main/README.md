# Create Renewable Ores

A Datapack/Mod for [Create Farbic](https://modrinth.com/mod/create-fabric) that adds renewable recipes for crimsite, ochrum, veridium, and asurine.

These can be crushed to iron/gold/zinc/copper, thus renewable ores.

Recipes based on [CreatePlus](https://github.com/JieningYu/CreatePlus-mod/)'s, with slight modification.
